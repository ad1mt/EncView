unit Main;

{$mode objfpc}{$H+}

(*------------------------------*)
{
v5.00	1.	Form scaling
v5.01	1.	Validate password
v6.02	1.	Built with Unit_PRNG v4.13.00
v6.03	1.	Bug fix - if wrong password entered, could not be fixed.
v6.03B	1.	Built with Unit_PRNG v4.14.00. No functionality change.
v6.04	1.	Built with Unit_PRNG v4.14.00, with EncPRNG bug fix.
}

interface

uses	Classes
,		SysUtils
,		Forms
,		Controls
,		Graphics
,		Dialogs
,		StdCtrls
,		XMLPropStorage
,		Encrypt_P
,		Unit_PRNG
;

{$include Int_Common_Types.inc}

const
	VERSION = '6.03';
	WHO_I_AM= 'EncView '+VERSION;
	HIDDEN_PASSWORD = '*';
	DEFAULT_TEXT = 'Enter your text here';

type

	{ TForm1 }

 TForm1 = class(TForm)
	Button1: TButton;
	Button2: TButton;
	Button3: TButton;
	Button4: TButton;
	Button5: TButton;
	CheckBox1: TCheckBox;
	Label1: TLabel;
	Password: TEdit;
	Text1: TMemo;
	OpenDialog1: TOpenDialog;
	SaveDialog1: TSaveDialog;
	XMLPropStorage1: TXMLPropStorage;
	procedure Button1Click(Sender: TObject);
	procedure Button2Click(Sender: TObject);
	procedure Button3Click(Sender: TObject);
	procedure Button4Click(Sender: TObject);
	procedure Button5Click(Sender: TObject);
	procedure FormActivate(Sender: TObject);
	procedure FormCreate(Sender: TObject);
	procedure FormResize(Sender: TObject);
	procedure Text1Change(Sender: TObject);
	procedure PasswordChange(Sender: TObject);
	// procedure save;
	private
	public
	end;

var
	Form1			:TForm1;
	Text1_Changed	:boolean = FALSE;
	Password_Changed:boolean = FALSE;

implementation

{$R *.lfm}

{ TForm1 }

{=============================================}
procedure TForm1.Button1Click(Sender: TObject);
begin
if Password_Changed then
	begin
	Case validate_password(Password.Text) of
		PRNG_ERROR_PASSWORD_LEN:
			begin
			showmessage('Password must be 1 to 77 characters long');
			exit;
			end;
		PRNG_ERROR_PASSWORD_CHARS:
			begin
			showmessage('Password must not contain international characters');
			exit;
			end;
		end; { Case }
	PASSWORD_STR:= Password.Text;
	Password.Text:= HIDDEN_PASSWORD;
	Password_Changed:= FALSE;
	end;
if	(PASSWORD_STR = '') then
	begin
	showmessage('Password must be entered');
	exit;
	end;
if not OpenDialog1.Execute then exit;
INPUT_FILE_NAME:= OpenDialog1.FileName;
OUTPUT_FILE_NAME:= '';
if (INPUT_FILE_NAME = '') then exit;
open_input_file;
if (ERROR_CODE <> T_ERR_OK) then
	begin
	showmessage(ERROR_MESS + sLineBreak + 'File not loaded');
	ERROR_CODE:= T_ERR_OK;
	close_input_file;
	exit;
	end;
decrypt;
if (ERROR_CODE <> T_ERR_OK) then
	begin
	showmessage(ERROR_MESS + sLineBreak + 'File not loaded');
	ERROR_CODE:= T_ERR_OK;
	close_input_file;
	exit;
	end;
Text1.Text:= CLEAR_STR;
Text1_Changed:= FALSE;
Form1.Caption:= INPUT_FILE_NAME;
close_input_file;
end;

{=============================================}
procedure TForm1.Button2Click(Sender: TObject);
begin
if	Text1_Changed
and	not CheckBox1.Checked
then
	begin
    showmessage('There are unsaved changes!');
	end
else Halt;
end;

{=============================================}
procedure TForm1.Button3Click(Sender: TObject);
begin
if Password_Changed then
	begin
	Case validate_password(Password.Text) of
		PRNG_ERROR_PASSWORD_LEN:
			begin
			showmessage('Password must be 1 to 77 characters long');
			exit;
			end;
		PRNG_ERROR_PASSWORD_CHARS:
			begin
			showmessage('Password must not contain international characters');
			exit;
			end;
		end; { Case }
	PASSWORD_STR:= Password.Text;
	Password.Text:= HIDDEN_PASSWORD;
	Password_Changed:= FALSE;
	end;
if	(PASSWORD_STR = '') then
	begin
	showmessage('Password must be entered');
	ERROR_CODE:= T_ERR_OK;
	exit;
	end;
OUTPUT_FILE_NAME:= INPUT_FILE_NAME;
if (OUTPUT_FILE_NAME = '') then
	begin
    showmessage('No file is loaded');
	exit;
	end;
open_output_file;
if (ERROR_CODE <> T_ERR_OK) then
	begin
	showmessage(ERROR_MESS + sLineBreak + 'File not saved');
	ERROR_CODE:= T_ERR_OK;
	exit;
	end;
CLEAR_STR:= Text1.Text;
Encrypt;
close_output_file;
showmessage('File saved ok');
Text1_Changed:= FALSE;
end;

{=============================================}
procedure TForm1.Button4Click(Sender: TObject);
begin
if Password_Changed then
	begin
	Case validate_password(Password.Text) of
		PRNG_ERROR_PASSWORD_LEN:
			begin
			showmessage('Password must be 1 to 77 characters long');
			exit;
			end;
		PRNG_ERROR_PASSWORD_CHARS:
			begin
			showmessage('Password must not contain international characters');
			exit;
			end;
		end; { Case }
	PASSWORD_STR:= Password.Text;
	Password.Text:= HIDDEN_PASSWORD;
	Password_Changed:= FALSE;
	end;
if	(PASSWORD_STR = '') then
	begin
	showmessage('Password must be entered');
	ERROR_CODE:= T_ERR_OK;
	exit;
	end;
if	Text1_Changed then
	CLEAR_STR:= Text1.Text
else if (Text1.Text = DEFAULT_TEXT) then
	CLEAR_STR:= '';

if	(CLEAR_STR = '') then
	begin
	showmessage('Text must be entered');
	ERROR_CODE:= T_ERR_OK;
	exit;
	end;

if not SaveDialog1.Execute then exit;
OUTPUT_FILE_NAME:= SaveDialog1.FileName;
if (OUTPUT_FILE_NAME = '') then exit;
open_output_file;
if (ERROR_CODE <> T_ERR_OK) then
	begin
	showmessage(ERROR_MESS + sLineBreak + 'File not saved');
	ERROR_CODE:= T_ERR_OK;
	exit;
	end;
Encrypt;
if (ERROR_CODE <> T_ERR_OK) then
	begin
	showmessage(ERROR_MESS + sLineBreak + 'File not saved');
	ERROR_CODE:= T_ERR_OK;
	exit;
	end
else
	begin
	showmessage('File saved ok');
	Text1_Changed:= FALSE;
	end;

INPUT_FILE_NAME:= OUTPUT_FILE_NAME;
Form1.Caption:= INPUT_FILE_NAME;
close_output_file;
Form1.Password.Text:= HIDDEN_PASSWORD;
end;

{=============================================}
procedure TForm1.Button5Click(Sender: TObject);
begin
if Password_Changed then
	begin
	Case validate_password(Password.Text) of
		PRNG_ERROR_PASSWORD_LEN:
			begin
			showmessage('Password must be 1 to 77 characters long');
			exit;
			end;
		PRNG_ERROR_PASSWORD_CHARS:
			begin
			showmessage('Password must not contain international characters');
			exit;
			end;
		end; { Case }
	PASSWORD_STR:= Password.Text;
	Password.Text:= HIDDEN_PASSWORD;
	Password_Changed:= FALSE;
	end;
if (PASSWORD_STR = '') then
	showmessage('Password has not been entered yet')
else
	showmessage('Password is:'+sLineBreak+'"'+PASSWORD_STR+'"');
end;

{=============================================}
procedure TForm1.FormActivate(Sender: TObject);
begin
end;

{=============================================}
procedure TForm1.FormCreate(Sender: TObject);
begin
Form1.Caption:= WHO_I_AM;
Text1.Text:= DEFAULT_TEXT;
Text1_Changed:= FALSE;
end;


{=============================================}
procedure TForm1.FormResize(Sender: TObject);
begin
Text1.Width:= (Form1.Width - 30);
Password.Width:= (Form1.Width - 30);
Text1.Height:= (Form1.Height - 160);
Password.Top:= (Form1.Height - 130);
Button1.Top:= (Form1.Height - 70);
Button2.Top:= (Form1.Height - 70);
Button3.Top:= (Form1.Height - 70);
Button4.Top:= (Form1.Height - 70);
Button5.Top:= (Form1.Height - 70);
CheckBox1.Top:= (Form1.Height - 60);
Label1.Top:= (Form1.Height - 70);
end;

{=============================================}
procedure TForm1.Text1Change(Sender: TObject);
begin
Text1_Changed:= TRUE;
end;

{=============================================}
procedure TForm1.PasswordChange(Sender: TObject);
begin
Password_Changed:= TRUE;
end;

{=============================================}
begin
PASSWORD_STR:='';
end.

