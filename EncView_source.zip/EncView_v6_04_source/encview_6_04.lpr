program encview_6_04;

{$mode objfpc}{$H+}

uses
	{$IFDEF UNIX}
	cthreads,
	{$ENDIF}
	{$IFDEF HASAMIGA}
	athreads,
	{$ENDIF}
	Interfaces // this includes the LCL widgetset
,	Forms
,	Main
,	Encrypt_P, Unit_PRNG
;

{$R *.res}

begin
	RequireDerivedFormResource:=True;
  Application.Scaled:=True;
	Application.Initialize;
    Application.CreateForm(TForm1, Form1);
	Form1.Caption:= WHO_I_AM;
	Application.Run;
end.

