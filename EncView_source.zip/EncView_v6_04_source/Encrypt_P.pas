{$MODE OBJFPC}
{$MODESWITCH NESTEDCOMMENTS+}

unit Encrypt_P;

(*------------------------------*)
{
v4.01	1.	Use new EncPRNG unit.
v4.02	2.	Replace error message of '0' with 'Unknown error'.
v4.03	1.	Validate password
v6.01	1.	Compress data before encrypting; decompress after decrypting.
v6.02	1.	Built with Unit_PRNG v4.13.00
v6.03	1.	Built with Multi_Int v5.17
		2.	Big fux: incorrect password cannot be fixed by
			re-entering the correct password.
}

INTERFACE

uses	sysutils
,		classes
,		Interfaces
,		Forms
,		ZStream
,		Unit_PRNG
;

{$IFDEF CPU64}
	{$define 64bit}
{$ELSE}
  	{$define 32bit}
{$ENDIF}

const
VERSION				= '6.03';
WHO_I_AM			= 'Marks Encrypt';
WHO_I_AM_VERSION	= WHO_I_AM + ' v' + VERSION;

type
T_ERROR_CODE	= (T_ERR_OK, T_ERR_INTERNAL, T_ERR_FILE, T_ERR_PRNG, T_ERR_DECOMPRESS);

var
PASSWORD_STR,
OUTPUT_FILE_NAME,
INPUT_FILE_NAME,
CLEAR_STR		:ansistring;

ERROR_CODE		:T_ERROR_CODE;
ERROR_MESS		:ansistring;

Compressor		: TCompressionStream;
Decompressor	: TDecompressionStream;
StringStream	: TStringStream;
CompressedData,
G_Stream		: TMemoryStream;

procedure open_input_file;
procedure open_output_file;
procedure close_input_file;
procedure close_output_file;
procedure Encrypt;
procedure Decrypt;

IMPLEMENTATION

var
OUTPUT_FILE,
INPUT_FILE		:FILE;
PRNG1			:T_PRNG_record;
PRNG_ERROR		:int64u;


(*------------------------------*)
procedure open_input_file;
var	IOResult_var:int64;
begin
assign(INPUT_FILE,INPUT_FILE_NAME);
{$I-}
reset(INPUT_FILE,1);
{$I+}

IOResult_var:= IOResult;
if (IOResult_var <> 0) then
	begin
	ERROR_MESS:= inttostr(IOResult_var);
	if (ERROR_MESS = '0') then ERROR_MESS:= 'Input file unknown error';
	ERROR_CODE:= T_ERR_FILE;
	exit;
	end
else ERROR_CODE:= T_ERR_OK;
end;

(*------------------------------*)
procedure open_output_file;
begin
assign(OUTPUT_FILE,OUTPUT_FILE_NAME);
{$I-}
rewrite(OUTPUT_FILE,1);
{$I+}
if (IoResult <> 0) then
	begin
	ERROR_MESS:= inttostr(IOResult);
	if (ERROR_MESS = '0') then ERROR_MESS:= 'Output file unknown error';
	ERROR_CODE:= T_ERR_FILE;
	exit;
	end
else ERROR_CODE:= T_ERR_OK;
end;


(*------------------------------*)
procedure close_output_file;
begin
{$I-}
close(OUTPUT_FILE);
{$I+}
if (IoResult <> 0) then
	begin
	ERROR_MESS:= inttostr(IOResult);
	if (ERROR_MESS = '0') then ERROR_MESS:= 'Output file unknown error';
	ERROR_CODE:= T_ERR_FILE;
	exit;
	end
else ERROR_CODE:= T_ERR_OK;
end;


(*------------------------------*)
procedure close_input_file;
begin
{$I-}
close(INPUT_FILE);
{$I+}
if (IoResult <> 0) then
	begin
	ERROR_MESS:= inttostr(IOResult);
	if (ERROR_MESS = '0') then ERROR_MESS:= 'Input file unknown error';
	ERROR_CODE:= T_ERR_FILE;
	exit;
	end
else ERROR_CODE:= T_ERR_OK;
end;


(*------------------------------*)
procedure Decrypt;
var
NUM_WRITTEN,
NUM_READ		:int32;

dt_byte			:int64u;

INPUT_BYTE,
OUTPUT_BYTE		:int8u;

DATE_TIME		:int64u;

begin
CLEAR_STR:= '';
DATE_TIME:= 0;

ERROR_CODE:= T_ERR_OK;
ERROR_MESS:= '';

PRNG_initialise(PRNG1);

// read date_time from encrypted file
DATE_TIME:= 0;
NUM_WRITTEN:= 0;
while (NUM_WRITTEN < 8) do
	begin
	{$I-}
	blockread(INPUT_FILE,INPUT_BYTE,1,NUM_READ);
	{$I+}
	if	(NUM_READ < 1)
	or	(IOResult > 0) then
		begin
		ERROR_MESS:= inttostr(IOResult);
		if (ERROR_MESS = '0') then ERROR_MESS:= 'Unknown error';
		ERROR_CODE:= T_ERR_FILE;
		exit;
		end;
    dt_byte:= int8u(INPUT_BYTE);
	dt_byte:= (dt_byte << (NUM_WRITTEN * 8));
    DATE_TIME:= (DATE_TIME + dt_byte);
	Inc(NUM_WRITTEN);
	end;

// randomise using date_time from encrypted file and password
// this initialises the PRNG with same seeds as encryption stage

PRNG_randomise_from_password(PRNG1,PASSWORD_STR,DATE_TIME,PRNG_ERROR);
if not PRNG1.INITIALISED then
	begin
	if (PRNG_ERROR = PRNG_ERROR_SEED) then
		ERROR_MESS:= 'Failed to initialise PRNG - possible input file corruption'
	else
		ERROR_MESS:= 'Failed to initialise PRNG - unknown error';
	ERROR_CODE:= T_ERR_PRNG;
	exit;
	end;

// read encrypted data from input file
G_stream:= TMemoryStream.Create();
NUM_READ:= -1;
while (NUM_READ <> 0) do
	begin
	{$I-}
	blockread(INPUT_FILE,INPUT_BYTE,1,NUM_READ);
	{$I+}
	if (IOResult > 0) then
		begin
		ERROR_MESS:= inttostr(IOResult);
		if (ERROR_MESS = '0') then ERROR_MESS:= 'Unknown error';
		ERROR_CODE:= T_ERR_FILE;
		exit;
		end;
	if	(NUM_READ > 0) then
		begin
	    OUTPUT_BYTE:= (INPUT_BYTE xor calc_8bit_rand(PRNG1));
		G_stream.writebyte(OUTPUT_BYTE);
		end;
	end;

{ Decompress the string }
G_stream.Position:= 0;
Decompressor   := TDecompressionStream.Create(G_stream);
StringStream   := TStringStream.Create;
try
	StringStream.CopyFrom(Decompressor, 0);
except
	ERROR_CODE:= T_ERR_DECOMPRESS;
	ERROR_MESS:= 'Decompress error';
end;
Decompressor.Destroy;
CLEAR_STR:= StringStream.DataString;

G_stream.Free;
StringStream.Free;
end;


(*------------------------------*)
procedure Encrypt;
var
i,
NUM_END,
NUM_WRITTEN,
NUM_READ		:int32;

INPUT_BYTE,
OUTPUT_BYTE		:int8u;

DATE_TIME		:int64u;

begin
PRNG_initialise(PRNG1);

// randomise using date_time and password

DATE_TIME:= 0;
PRNG_randomise_from_password(PRNG1,PASSWORD_STR,DATE_TIME,PRNG_ERROR);
if not PRNG1.INITIALISED then
	begin
	if (PRNG_ERROR = PRNG_ERROR_SEED) then
		ERROR_MESS:= 'Failed to initialise PRNG - please try again.'
	else
		ERROR_MESS:= 'Failed to initialise PRNG - unknown error';
	ERROR_CODE:= T_ERR_PRNG;
	exit;
	end;

// write date_time to output file

NUM_READ:= 0;
while (NUM_READ < 8) do
	begin
    OUTPUT_BYTE:= int8u(DATE_TIME and INT8U_MAXINT);
	{$I-}
	blockwrite(OUTPUT_FILE,OUTPUT_BYTE,1,NUM_WRITTEN);
	{$I+}
	if	(NUM_WRITTEN < 1)
	or	(IOResult > 0) then
		begin
		ERROR_MESS:= inttostr(IOResult);
		if (ERROR_MESS = '0') then ERROR_MESS:= 'Unknown error';
		ERROR_CODE:= T_ERR_FILE;
		exit;
		end;
    DATE_TIME:= (DATE_TIME >> 8);
	Inc(NUM_READ);
	end;

{ Create Streams }
StringStream:= TStringStream.Create(CLEAR_STR);
CompressedData := TMemoryStream.Create();
Compressor     := TCompressionStream.Create(clmax, CompressedData);

{ Compress the string }
Compressor.CopyFrom(StringStream, StringStream.Size);
Compressor.Destroy;
StringStream.Free;

// encrypt data & write to output file
CompressedData.Position := 0;
i:= 0;
while (i < CompressedData.Size) do
	begin
	INPUT_BYTE:= CompressedData.ReadByte;
    OUTPUT_BYTE:= (INPUT_BYTE xor calc_8bit_rand(PRNG1));
	{$I-}
	blockwrite(OUTPUT_FILE,OUTPUT_BYTE,1,NUM_WRITTEN);
	{$I+}
	if	(NUM_WRITTEN < 1)
	or	(IOResult > 0) then
		begin
		ERROR_MESS:= inttostr(IOResult);
		if (ERROR_MESS = '0') then ERROR_MESS:= 'Unknown error';
		ERROR_CODE:= T_ERR_FILE;
		exit;
		end;
	Inc(i);
	end;
CompressedData.Free;

ERROR_CODE:= T_ERR_OK;
ERROR_MESS:= '';
end;

begin

end.

